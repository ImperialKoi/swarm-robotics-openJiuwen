# SwarmMind

Hierarchical hivemind-controlled robot swarm for simulated disaster search and rescue.
Built for Hack the North 2026.

Three control tiers: a 20 Hz reflex layer, a 1 Hz decentralised task auction that self-heals
when robots die, and a locally-run LLM issuing sector-level strategy every 6 seconds under a JSON schema constraint.
The auction has no LLM in it, which is why the swarm keeps working when the hivemind goes offline.

- [CLAUDE.md](CLAUDE.md) — working rules and invariants
- [docs/PLAN.md](docs/PLAN.md) — scope, schedule, risk
- [docs/TECHNICAL.md](docs/TECHNICAL.md) — design of record
- [docs/DASHBOARD.md](docs/DASHBOARD.md) — **how to run the dashboard and read a run**

```bash
uv sync
make check                                          # lint + tests + a full headless mission
uv run python -m swarmmind.cli run --headless --seed 42
```
