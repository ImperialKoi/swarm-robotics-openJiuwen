"""Offline 3D renderer. Point-splat rasteriser with a z-buffer, numpy only.

**This exists so 3D work is not done blind.** Godot cannot be run from the development
environment, and neither can a browser, so camera maths, eye-height framing and the
extrusion of the occupancy grid would otherwise be written unseen and debugged by
proxy. Rendering the same scene here produces PNGs that can actually be looked at, and
Godot then implements maths that has already been verified.

It is not a game renderer and does not need to be: splats with a depth buffer and
cheap directional shading are enough to confirm that a scene is geometrically right.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..sim import grid
from ..sim.robot import LANES
from ..viz.render import LANE_COLOR

#: Sun direction for the fake diffuse term. Low and off to one side so slopes read.
_LIGHT = np.array([0.45, 0.35, 0.82], dtype=np.float32)
_LIGHT /= np.linalg.norm(_LIGHT)

#: Overcast, dust-laden sky. Near-flat on purpose: a clear blue gradient reads as a
#: pleasant afternoon, which is the wrong register for a collapsed city.
SKY_TOP = np.array([118, 120, 112], dtype=np.float32)
SKY_HORIZON = np.array([172, 168, 152], dtype=np.float32)

#: Airborne dust, pooling low the way real haze does.
#:
#: Plain distance fog is wrong here: the operator's camera sits ~340 m out, so any
#: density thick enough to feel atmospheric in first-person erases the entire map from
#: the eagle view. Attenuating density with altitude fixes both at once -- an exponential
#: atmosphere is what actually happens, and it happens to be exactly what a dashboard
#: needs. Down among the rubble it is thick; from above you look straight through it.
FOG_COLOR = np.array([168, 165, 150], dtype=np.float32)
FOG_DENSITY = 0.020
FOG_SCALE_HEIGHT = 14.0
FOG_MAX = 0.93

#: **Display palette, deliberately separate from perception/raster.py.**
#:
#: The appearance raster is tuned for the detector: dark ground, warm rubble that is
#: genuinely confusable with a casualty, low contrast. Those are the right choices for
#: computer vision and the wrong ones for a human watching a dashboard. What the cameras
#: see and what the operator sees are different problems, so they get different palettes.
DISPLAY_FLOOR = np.array([104, 101, 86], dtype=np.float32)
DISPLAY_RUBBLE = np.array([116, 95, 73], dtype=np.float32)
DISPLAY_WALL = np.array([150, 146, 135], dtype=np.float32)
#: How much darker a vertical face is than a lit top.
SIDE_SHADE = 0.52

#: Water, drawn as a surface at `height + depth` rather than as a tint on the bed.
#:
#: Without it a river is a dry trench with a dark scratch down it, which is exactly what
#: the terrain looked like before: the `water` field gated traversal but nothing drew it,
#: so the one feature that divides the map was invisible to the person watching. Shallow
#: water keeps some of the bed's colour, deep water hides it, and both carry a wash of
#: sky because a flat surface under an overcast sky is mostly reflecting it.
WATER_SHALLOW = np.array([92, 108, 100], dtype=np.float32)
WATER_DEEP = np.array([38, 58, 76], dtype=np.float32)
WATER_SKY_MIX = 0.26
#: Depth at which water reaches its deep colour. Rivers run to ~1.1 m, marsh to ~0.4, so
#: the two tiers of barrier are visibly different tiers.
WATER_OPAQUE_M = 0.85


@dataclass
class Camera3D:
    pos: np.ndarray
    target: np.ndarray
    fov_deg: float = 62.0
    up: tuple[float, float, float] = (0.0, 0.0, 1.0)


class Renderer3D:
    def __init__(self, world, width: int = 960, height: int = 600,
                 side_step: float = 0.5) -> None:
        self.w, self.h = width, height
        self.cell = world.cell
        self.shape = world.shape
        self._build_points(world, side_step)

    # ------------------------------------------------------------------ geometry

    def _build_points(self, world, side_step: float) -> None:
        """One splat per cell top, plus splats down the side of anything tall.

        The side points are what turn a heightfield into visible blocks: without them a
        wall reads as a bright patch of floor rather than a solid obstruction.
        """
        h, w = self.shape
        gy, gx = np.mgrid[0:h, 0:w]
        x = (gx + 0.5) * self.cell
        y = (gy + 0.5) * self.cell
        z = world.height

        albedo = np.empty((*self.shape, 3), dtype=np.float32)
        albedo[:] = DISPLAY_FLOOR
        albedo[world.occ == grid.RUBBLE] = DISPLAY_RUBBLE
        albedo[world.occ == grid.WALL] = DISPLAY_WALL
        # Slight per-cell variation so large flat areas do not band.
        albedo *= (0.90 + 0.20 * world.rng["map"].random((*self.shape, 1))).astype(np.float32)

        # Shading from the heightfield gradient, so slopes and block faces separate.
        dzdy, dzdx = np.gradient(z, self.cell)
        nrm = np.stack([-dzdx, -dzdy, np.ones_like(z)], axis=-1)
        nrm /= np.linalg.norm(nrm, axis=-1, keepdims=True)
        diffuse = np.clip((nrm @ _LIGHT), 0.0, 1.0) * 0.75 + 0.25

        pts = [np.stack([x.ravel(), y.ravel(), z.ravel()], axis=1)]
        cols = [(albedo * diffuse[..., None]).reshape(-1, 3)]
        self._cell_index = [np.arange(h * w)]

        # Skirt depth is the drop to the LOWEST NEIGHBOUR, not the height above the map
        # floor. Those were the same thing while the map was flat; with 50 m of relief on
        # it they are not, and keying on the floor meant a 40 m peak got skirts it did not
        # need while the cells on its flank -- each a metre above the next one down -- got
        # none, so the steep faces broke into horizontal stripes with the bed showing
        # through. A cell only ever needs to cover the gap to its own neighbour.
        zp = np.pad(z, 1, mode="edge")
        drop = np.clip(z - np.minimum.reduce([zp[:-2, 1:-1], zp[2:, 1:-1],
                                              zp[1:-1, :-2], zp[1:-1, 2:]]), 0.0, None)
        # The map's own rim is the exception: it has no neighbour to gap against, but it
        # is the outside face of the slab and has to be solid or the eagle view looks
        # through the edge of the world. `np.roll` here would be worse than wrong -- it
        # compares each border cell to the far side of the map.
        rim = np.zeros(self.shape, dtype=bool)
        rim[0], rim[-1], rim[:, 0], rim[:, -1] = True, True, True, True
        drop[rim] = np.maximum(drop[rim], (z - z.min())[rim])
        for k in range(1, int(min(256, np.ceil(drop.max() / side_step))) + 1):
            depth = k * side_step
            m = drop > depth
            if not m.any():
                break
            pts.append(np.stack([x[m], y[m], (z - depth)[m]], axis=1))
            # Sides are darker than tops: a flat-shaded block with identical faces has
            # no silhouette at all. One constant, not a per-layer ramp -- a 1 m rubble
            # block only ever shows one or two layers, but a mountain flank shows twenty,
            # and a ramp across twenty of them paints the flank in horizontal bands.
            cols.append(albedo[m] * SIDE_SHADE)
            self._cell_index.append(np.nonzero(m.ravel())[0])

        # Water last, so its splats sit above the bed they cover in the z-buffer.
        wp, wc, wi = self._water_points(world, x, y, albedo)
        if len(wp):
            pts.append(wp)
            cols.append(wc)
            self._cell_index.append(wi)

        self.points = np.concatenate(pts).astype(np.float32)
        self.base_colors = np.clip(np.concatenate(cols), 0, 255).astype(np.float32)
        self.cell_of_point = np.concatenate(self._cell_index)

    def _water_points(self, world, x: np.ndarray, y: np.ndarray, albedo: np.ndarray):
        """A splat per wet cell, at the water surface.

        The surface is flat, so it takes one shading value rather than the heightfield's
        gradient -- which is the point: a still sheet at a constant angle to the light is
        what separates water from wet-looking ground.
        """
        depth = world.water
        m = depth > 0.02
        if not m.any():
            return np.zeros((0, 3), np.float32), np.zeros((0, 3), np.float32), \
                np.zeros(0, np.int64)
        d = np.clip(depth[m] / WATER_OPAQUE_M, 0.0, 1.0)[:, None]
        col = WATER_SHALLOW * (1.0 - d) + WATER_DEEP * d
        # Shallow water lets the bed through; deep water does not.
        col = col * (0.55 + 0.45 * d) + albedo[m] * 0.45 * (1.0 - d)
        col = col * (1.0 - WATER_SKY_MIX) + SKY_HORIZON * WATER_SKY_MIX
        flat = float(_LIGHT[2]) * 0.75 + 0.25          # a level surface, one normal
        pts = np.stack([x[m], y[m], (world.height + depth)[m]], axis=1)
        return (pts.astype(np.float32), (col * flat).astype(np.float32),
                np.nonzero(m.ravel())[0])

    # ------------------------------------------------------------------ camera

    def orbit(self, world, azimuth_deg: float = 235.0, elevation_deg: float = 34.0,
              dist_frac: float = 1.15) -> Camera3D:
        """Operator's eagle view: an orbit around the map centre."""
        cx = world.scn.map.width_m * 0.5
        cy = world.scn.map.height_m * 0.5
        span = max(world.scn.map.width_m, world.scn.map.height_m) * dist_frac
        a, e = np.deg2rad(azimuth_deg), np.deg2rad(elevation_deg)
        pos = np.array([cx + np.cos(a) * np.cos(e) * span,
                        cy + np.sin(a) * np.cos(e) * span,
                        float(world.height.max()) + np.sin(e) * span], dtype=np.float32)
        return Camera3D(pos=pos, target=np.array([cx, cy, 0.0], dtype=np.float32), fov_deg=48.0)

    def pov(self, world, i: int, eye: float = 1.1, look_ahead: float = 14.0) -> Camera3D:
        """What robot ``i`` is looking at. Eye height sits above its own chassis."""
        ix = int(np.clip(world.pos[i, 0] / self.cell, 0, self.shape[1] - 1))
        iy = int(np.clip(world.pos[i, 1] / self.cell, 0, self.shape[0] - 1))
        ground = float(world.height[iy, ix])
        th = float(world.theta[i])
        pos = np.array([world.pos[i, 0], world.pos[i, 1], ground + eye], dtype=np.float32)
        fwd = np.array([np.cos(th), np.sin(th), -0.12], dtype=np.float32)
        return Camera3D(pos=pos, target=pos + fwd * look_ahead, fov_deg=74.0)

    #: Third-person follow, the view between the 260 m orbit and the robot's own eye.
    #: The distance was chosen off `runs/3d/chase*.png`: at 4 m the 1.4 m chassis is
    #: about a fifth of the frame and unmistakably the subject, while the ground it is
    #: about to cross is still in shot -- which is the whole point of this view. An orbit
    #: shows the swarm, a POV shows the fog, and neither shows one unit *doing*
    #: something. At 5 m the near-field rubble starts winning the frame.
    CHASE_DIST = 4.0
    #: 17.2 deg is the 0.30 rad `CHASE_PITCH` the dashboard starts at, to the digit.
    CHASE_ELEV_DEG = 17.2
    #: **Vertical**, because that is what `Camera3D.fov` means in Godot under the default
    #: `KEEP_HEIGHT`, and this camera is close enough that mistaking one for the other
    #: changes the framing by a third. `Camera3D.fov_deg` here is horizontal, so the two
    #: are converted through the frame aspect rather than copied across as one number.
    CHASE_FOV_V = 55.0
    #: Look at the middle of the chassis, not its feet: the box is drawn 1.2 m tall
    #: centred 0.6 m up, so this is its waist and the unit sits on the frame centre.
    CHASE_ANCHOR_Z = 0.7
    #: Minimum height above the terrain under the eye. A chase camera reversing into a
    #: hillside is the classic third-person failure and the heightfield is already here.
    CHASE_CLEARANCE = 0.7

    def chase(self, world, i: int, dist: float = CHASE_DIST,
              elevation_deg: float = CHASE_ELEV_DEG, yaw_off_deg: float = 0.0,
              anchor_off=(0.0, 0.0, 0.0)) -> Camera3D:
        """Third-person camera behind robot ``i``, looking at it.

        Reference for `_chase_camera` in godot/scripts/main.gd -- same anchor height,
        same azimuth convention (0 = directly behind the heading, so the unit leads the
        frame and the camera swings round as it turns), same terrain clearance.
        The three arguments are the three controls: ``yaw_off_deg`` is the drag,
        ``dist`` the wheel, and ``anchor_off`` the right-drag that slides the unit
        around inside the frame.
        """
        ix = int(np.clip(world.pos[i, 0] / self.cell, 0, self.shape[1] - 1))
        iy = int(np.clip(world.pos[i, 1] / self.cell, 0, self.shape[0] - 1))
        ground = float(world.height[iy, ix])
        anchor = np.array([world.pos[i, 0], world.pos[i, 1],
                           ground + self.CHASE_ANCHOR_Z], dtype=np.float32)
        anchor = anchor + np.asarray(anchor_off, dtype=np.float32)
        az = float(world.theta[i]) + np.pi + np.deg2rad(yaw_off_deg)
        e = np.deg2rad(elevation_deg)
        pos = anchor + np.array([np.cos(az) * np.cos(e),
                                 np.sin(az) * np.cos(e),
                                 np.sin(e)], dtype=np.float32) * dist
        ex = int(np.clip(pos[0] / self.cell, 0, self.shape[1] - 1))
        ey = int(np.clip(pos[1] / self.cell, 0, self.shape[0] - 1))
        pos[2] = max(float(pos[2]), float(world.height[ey, ex]) + self.CHASE_CLEARANCE)
        fov_h = np.rad2deg(2.0 * np.arctan(
            np.tan(np.deg2rad(self.CHASE_FOV_V) * 0.5) * self.w / self.h))
        return Camera3D(pos=pos, target=anchor, fov_deg=float(fov_h))

    # ------------------------------------------------------------------ render

    #: Tier 3 overlay tints, keyed by sector priority. Abandonment overrides all three.
    #: Deliberately weak (`SECTOR_TINT_MIX`) -- this is a wash over the terrain, not a
    #: repaint. An overlay that hides the map it annotates is worse than no overlay.
    SECTOR_TINT = {
        0: np.array([120, 200, 255], np.float32),   # high     -- cool, "look here"
        2: np.array([90, 90, 110], np.float32),     # low      -- drained
    }
    #: Amber, not red. Red is the hazard, and "on fire" and "written off by the hivemind"
    #: are different claims -- a judge who cannot tell them apart learns nothing from
    #: either. Matches the `sector_abandoned` colour in the dashboard's event feed.
    SECTOR_TINT_ABANDONED = np.array([255, 210, 74], np.float32)
    SECTOR_TINT_MIX = 0.30

    def render(self, world, cam: Camera3D, *, fog: bool = True,
               robots: bool = True, hide: int | None = None,
               sectors: bool = False, fx=None) -> np.ndarray:
        img = self._sky()
        zbuf = np.full((self.h, self.w), np.inf, dtype=np.float32)

        cols = self.base_colors.copy()
        if fog:
            seen = world.explored.ravel()[self.cell_of_point]
            cols[~seen] *= 0.28
        if sectors:
            cols = self._tint_sectors(world, cols)
        if world.hazard.active and world.hazard.radius > 0:
            d = np.linalg.norm(self.points[:, :2] - world.hazard.centre[None, :], axis=1)
            burning = d <= world.hazard.radius
            cols[burning] = cols[burning] * 0.35 + np.array([255, 92, 28], np.float32) * 0.65

        self._ground_fill(img, zbuf, cam)
        self._splat(img, zbuf, cam, self.points, cols, scale=self.cell * 1.5)

        if robots:
            rp, rc = self._robot_points(world, hide)
            if len(rp):
                self._splat(img, zbuf, cam, rp, rc, scale=1.9)

        # Particles last, and they do not write depth. They are alpha-blended dust in
        # front of a solid world; letting them into the z-buffer would have every puff
        # occlude the one behind it and the plume would read as a stack of discs. This
        # is the pass godot/scripts/main.gd's particle MultiMesh is a port of -- the
        # integration and the per-kind constants come from swarmmind/viz/particles.py,
        # which both sides share.
        if fx is not None and len(fx):
            pp, pc, pa, ps = fx.points()
            self._splat(img, zbuf, cam, pp, pc, scale=ps, alpha=pa, write_depth=False)
        return np.clip(img, 0, 255).astype(np.uint8)

    def _tint_sectors(self, world, cols: np.ndarray) -> np.ndarray:
        """Wash each cell with its sector's Tier 3 state.

        This is the whole point of a strategic layer being visible: a judge should be able
        to watch the map change colour when the hivemind speaks, and see the swarm leave.
        """
        sec = world.sector_of_cell.ravel()[self.cell_of_point]
        for k in range(len(world.sector_ids)):
            if world.sector_abandoned[k]:
                tint = self.SECTOR_TINT_ABANDONED
            else:
                tint = self.SECTOR_TINT.get(int(world.sector_priority[k]))
                if tint is None:
                    continue
            m = sec == k
            if m.any():
                cols[m] = cols[m] * (1.0 - self.SECTOR_TINT_MIX) + tint * self.SECTOR_TINT_MIX
        return cols

    def _robot_points(self, world, hide: int | None):
        alive = world.status <= 1
        idx = np.nonzero(alive)[0]
        if hide is not None:
            idx = idx[idx != hide]
        if len(idx) == 0:
            return np.zeros((0, 3), np.float32), np.zeros((0, 3), np.float32)
        ix = np.clip((world.pos[idx, 0] / self.cell).astype(int), 0, self.shape[1] - 1)
        iy = np.clip((world.pos[idx, 1] / self.cell).astype(int), 0, self.shape[0] - 1)
        ground = world.height[iy, ix]
        pts, cols = [], []
        for dz in (0.3, 0.6, 0.9, 1.2, 1.5):
            pts.append(np.stack([world.pos[idx, 0], world.pos[idx, 1], ground + dz], axis=1))
            shade = 1.0 if dz > 0.6 else 0.7
            c = np.array([LANE_COLOR[LANES[a]] for a in world.actuator[idx]], np.float32)
            c = c * shade
            c[world.status[idx] == 1] *= 0.45           # out of contact
            cols.append(c)
        return (np.concatenate(pts).astype(np.float32),
                np.concatenate(cols).astype(np.float32))

    def _ground_fill(self, img, zbuf, cam: Camera3D) -> None:
        """Paint the ground plane below the horizon before anything else.

        Splats alone cannot cover the near field from eye height: a 0.5 m cell two
        metres away subtends far more screen area than any sane splat cap, so the floor
        breaks into confetti and sky shows through it. Below the horizon every view ray
        meets the ground eventually, so filling it is not a hack -- it is the plane at
        infinity, and the splats then draw the detail on top.
        """
        fwd = cam.target - cam.pos
        fwd = fwd / np.linalg.norm(fwd)
        horiz = np.array([fwd[0], fwd[1], 0.0], dtype=np.float32)
        if np.linalg.norm(horiz) < 1e-6:
            return
        horiz /= np.linalg.norm(horiz)
        up = np.asarray(cam.up, dtype=np.float32)
        right = np.cross(fwd, up)
        right /= np.linalg.norm(right)
        upv = np.cross(right, fwd)

        far = cam.pos + horiz * 1e5
        d = far - cam.pos
        cz = float(d @ fwd)
        if cz <= 0:
            return
        f = (self.w * 0.5) / np.tan(np.deg2rad(cam.fov_deg) * 0.5)
        y_h = int(self.h * 0.5 - (d @ upv) / cz * f)
        if y_h >= self.h:
            return
        y0 = max(0, y_h)
        rows = self.h - y0
        if rows <= 0:
            return
        # Fade toward the horizon so the far plane reads as distance, not a flat band.
        t = np.linspace(0.0, 1.0, rows, dtype=np.float32)[:, None]
        haze = float(np.exp(-max(cam.pos[2], 0.0) / (FOG_SCALE_HEIGHT * 2.5)))
        far_col = FOG_COLOR * haze + DISPLAY_FLOOR * 0.9 * (1.0 - haze)
        band = far_col[None, :] * (1 - t) + (DISPLAY_FLOOR * 0.85)[None, :] * t
        img[y0:, :, :] = band[:, None, :]

    def _sky(self) -> np.ndarray:
        t = np.linspace(0.0, 1.0, self.h, dtype=np.float32)[:, None]
        band = SKY_TOP[None, :] * (1 - t) + SKY_HORIZON[None, :] * t
        return np.repeat(band[:, None, :], self.w, axis=1).copy()

    def _splat(self, img, zbuf, cam: Camera3D, pts, cols, scale, *,
               alpha=None, write_depth: bool = True) -> None:
        """Project points and paint them, nearest-first.

        ``scale`` is metres of splat width and may be a scalar or one value per point --
        particles carry their own size and grow over their life, so a single figure would
        draw a settling dust cloud at the size it was born.
        """
        fwd = cam.target - cam.pos
        fwd = fwd / np.linalg.norm(fwd)
        up = np.asarray(cam.up, dtype=np.float32)
        right = np.cross(fwd, up)
        right /= np.linalg.norm(right)
        upv = np.cross(right, fwd)

        d = pts - cam.pos[None, :]
        cx = d @ right
        cy = d @ upv
        cz = d @ fwd
        near = cz > 0.35
        if not near.any():
            return
        f = (self.w * 0.5) / np.tan(np.deg2rad(cam.fov_deg) * 0.5)
        sx = (self.w * 0.5 + cx[near] / cz[near] * f)
        sy = (self.h * 0.5 - cy[near] / cz[near] * f)
        sz = cz[near]
        sc = cols[near]
        scale = np.asarray(scale, dtype=np.float32)
        sscale = scale[near] if scale.ndim else scale
        salpha = None if alpha is None else np.asarray(alpha, dtype=np.float32)[near]

        # Exponential distance fog, applied per fragment before the depth test. Doing it
        # here rather than as a post-process keeps it renderer-independent -- the Godot
        # shader computes the identical term, so these frames stay a truthful preview.
        mid_z = (cam.pos[2] + pts[near][:, 2]) * 0.5
        density = FOG_DENSITY * np.exp(-np.maximum(mid_z, 0.0) / FOG_SCALE_HEIGHT)
        fogf = np.clip(1.0 - np.exp(-density * sz), 0.0, FOG_MAX)[:, None]
        sc = sc * (1.0 - fogf) + FOG_COLOR[None, :] * fogf

        # Cap generously: from eye height the nearest cells legitimately need tens of
        # pixels, and clamping them low is exactly what produced the confetti floor.
        raw = np.clip(sscale * f / sz, 1.0, 56.0)
        px = sx.astype(np.int32)
        py = sy.astype(np.int32)

        # Bucket by splat size so each size is one vectorised scatter rather than a
        # per-point Python loop. Buckets are fine where splats are small and numerous,
        # coarse where they are large and few.
        buckets = [1, 2, 3, 4, 5, 6, 8, 10, 13, 17, 22, 28, 36, 46, 56]
        edges = np.array(buckets, dtype=np.float32)
        size = edges[np.searchsorted(edges, raw, side="left").clip(0, len(edges) - 1)]
        for k in buckets:
            m = size == k
            if not m.any():
                continue
            off = np.arange(k) - k // 2
            oy, ox = np.meshgrid(off, off, indexing="ij")
            xs = (px[m][:, None] + ox.ravel()[None, :]).ravel()
            ys = (py[m][:, None] + oy.ravel()[None, :]).ravel()
            zs = np.repeat(sz[m], k * k)
            cs = np.repeat(sc[m], k * k, axis=0)
            av = None if salpha is None else np.repeat(salpha[m], k * k)
            ok = (xs >= 0) & (xs < self.w) & (ys >= 0) & (ys < self.h)
            xs, ys, zs, cs = xs[ok], ys[ok], zs[ok], cs[ok]
            if av is not None:
                av = av[ok]
            if not len(xs):
                continue
            if write_depth:
                # Two-pass depth test: reduce to the nearest z per pixel, then write only
                # the fragments that won. Assignment with duplicate indices is otherwise
                # order-dependent and would flicker.
                np.minimum.at(zbuf, (ys, xs), zs)
            win = zs <= zbuf[ys, xs]
            if av is None:
                img[ys[win], xs[win]] = cs[win]
            else:
                a = av[win][:, None]
                img[ys[win], xs[win]] = img[ys[win], xs[win]] * (1.0 - a) + cs[win] * a
